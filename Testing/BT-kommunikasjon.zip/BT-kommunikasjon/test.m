
b=Bluetooth('MakerStudio',1)
fopen(b);
fprintf('Function started')
num = [7 3 7 3 7 3 ]; 
for i=1:5      
    fprintf('\n\n')
fprintf('Value sendt to arduino:  %d\n', num(i) )
 
fwrite(b, num(i)/250); 
fwrite(b, mod(num(i),250)); 



in1 = fscanf(b,'%f');
fprintf('What arduino received %s \n', in1); 

pause(10)
end

 fclose(b)  